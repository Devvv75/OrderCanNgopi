<!DOCTYPE html>
<html>
<head>
    <title>Order Cangopi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container text-center mt-5">
        <h1 class="text-success">INI HALAMAN WELCOME CUSTOM SAYA</h1>
        <p>Ini bukti bahwa file custom saya terbaca.</p>
    </div>
</body>
</html>