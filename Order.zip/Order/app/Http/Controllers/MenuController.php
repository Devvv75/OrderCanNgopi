<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class MenuController extends Controller
{
    public function getMenus()
    {
        $response = Http::get('https://pos-dev.canngopi.com/api/menus');

        if ($response->failed()) {
            return response()->json(['error' => 'Gagal ambil data'], 500);
        }

        $data = $response->json();

        if (!isset($data['data']) || !is_array($data['data'])) {
            return response()->json(['error' => 'Format data tidak valid'], 500);
        }

        return response()->json($data['data']);
    }
}
