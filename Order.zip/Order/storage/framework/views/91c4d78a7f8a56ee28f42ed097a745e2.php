<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Receipt</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 text-gray-800">

  <div class="container mx-auto px-4 py-8 max-w-2xl">
    <h1 class="text-2xl md:text-3xl font-bold text-center mb-6">Struk Pemesanan</h1>

    <div id="cart-container" class="bg-white rounded-xl shadow-md p-6 space-y-6">
      <div class="space-y-2 text-sm md:text-base">
        <div class="flex justify-between">
          <span class="font-semibold">Nama Pelanggan:</span>
          <span><?php echo e($customerName ?? 'Tidak diketahui'); ?></span>
        </div>
        <div class="flex justify-between">
          <span class="font-semibold">Tipe Pemesanan:</span>
          <span><?php echo e($orderType ? ucfirst($orderType) : 'Tidak diketahui'); ?></span>
        </div>
        <div class="flex justify-between">
          <span class="font-semibold">Waktu Pemesanan:</span>
          <span><?php echo e($createdAt ?? '-'); ?></span>
        </div>
      </div>

      <div>
        <h3 class="text-lg font-semibold border-b pb-2 mb-4">Pesanan</h3>
        <?php $total = 0; ?>
        <?php $__empty_1 = true; $__currentLoopData = $orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <?php
            $price = $item->price ?? 0;
            $quantity = $item->quantity ?? 0;
            $subtotal = $item->subtotal ?? ($price * $quantity);
            $total += $subtotal;
          ?>
          <div class="border-b border-dashed py-4 text-sm md:text-base">
            <p class="font-medium"><?php echo e($item->name ?? 'Tidak diketahui'); ?></p>
            <p>Harga Satuan: <span class="font-semibold">Rp <?php echo e(number_format($price, 0, ',', '.')); ?></span></p>
            <p>Jumlah: <span class="font-semibold"><?php echo e($quantity); ?></span></p>
            <p>Subtotal: <span class="font-semibold text-red-500">Rp <?php echo e(number_format($subtotal, 0, ',', '.')); ?></span></p>
            <?php if(!empty($item->notes)): ?>
              <p class="text-sm italic text-gray-600">Catatan: <?php echo e($item->notes); ?></p>
            <?php endif; ?>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <p class="text-center text-gray-500">Tidak ada item dalam pesanan.</p>
        <?php endif; ?>
      </div>

      <div class="text-right text-lg font-bold text-red-600 border-t pt-4">
        Total: Rp <?php echo e(number_format($total, 0, ',', '.')); ?>

      </div>
    </div>

    <div class="mt-6 text-center text-sm text-gray-600">
      <p>Silakan lakukan pembayaran di kasir.</p>
      <p>Terima kasih atas kunjungannya!</p>
    </div>
  </div>

  <script>
    localStorage.removeItem('cart');
  </script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\Order\resources\views/layouts/receipt.blade.php ENDPATH**/ ?>